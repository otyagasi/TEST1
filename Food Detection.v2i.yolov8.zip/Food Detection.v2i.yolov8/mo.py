

from ultralytics import YOLO

if __name__ == "__main__":
# ベースとするモデル        
    model = YOLO('runs/detect/train7/weights/last.pt')
    model.predict('test.jpg', save=True, conf=0.1)