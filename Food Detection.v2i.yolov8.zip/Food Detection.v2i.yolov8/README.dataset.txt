# Food Detection > 2024-05-05 3:29pm
https://universe.roboflow.com/flens-mikns/food-detection-guwga

Provided by a Roboflow user
License: Public Domain

